This repo contains the backend code supporting SamaritanOS. For more info, see https://github.com/thewoodfish/SamaritanOS
